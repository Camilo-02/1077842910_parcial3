package backend.IRepository;

import backend.Entity.Evento;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IEventoRepository extends JpaRepository <Evento,Long> {
}
