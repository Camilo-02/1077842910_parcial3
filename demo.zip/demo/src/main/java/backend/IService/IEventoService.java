package backend.IService;

import backend.Entity.Cliente;
import backend.Entity.Evento;

import java.util.List;
import java.util.Optional;

public interface IEventoService {
    List<Cliente> findAll();
    Optional<Cliente> findById(long id);
    Cliente save (Cliente cliente);
    void update (Cliente cliente, long id);

    Optional<Evento> findById(Long id);

    Evento save(Evento evento);

    void update(Evento evento, long id);

    void delete (long id);

    void update(Evento evento, Long id);

    void delete(Long id);
}
