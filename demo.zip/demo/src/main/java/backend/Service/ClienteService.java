package backend.Service;

import backend.Entity.Cliente;
import backend.IRepository.IClienteRepository;
import backend.IService.IClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClienteService implements IClienteService {

    @Autowired
    private IClienteRepository repository;
    @Override
    public List<Cliente> findAll(){return repository.findAll();}

    @Override
    public Optional<Cliente> findById(long id) {
        return Optional.empty();
    }

    @Override
    public Optional<Cliente> findById(Long id){return repository.findById(id);}

    @Override
    public Cliente save(Cliente cliente){return repository.save(cliente);}

    @Override
    public void update(Cliente cliente, long id) {

    }

    @Override
    public void delete(long id) {

    }

    @Override
    public void update(Cliente cliente, Long id){
        Optional<Cliente> ps = repository.findById(id);
        if (!ps.isEmpty()){
            Cliente clienteUpdate = ps.get();
            clienteUpdate.setNombre(cliente.getNombre());
            clienteUpdate.setCorreo_electronico(cliente.getCorreo_electronico());
            repository.save(clienteUpdate);
        }else{
            System.out.println("no existe el cliente");
        }
    }
    @Override
    public void delete(Long id){
        repository.deleteById(id);
    }


}
